import { Composer } from 'grammy'
import { InlineKeyboard } from 'grammy'

const keyboard = new InlineKeyboard()
    .url("Telegram Channel", "https://t.me/apktoaab")
    
const composer = new Composer()
composer.command('start', ctx => {
    const { from } = ctx
    ctx.reply(
        `Hello, <a href="tg://user?id=${from?.id}">${from?.first_name} ${from?.last_name?? ''}</a>`+
        `\nTo use the bot just send the APK to be converted to AAB`+
        `\nPs: <b>This bot is maintained by respect and donations.</b>` +
        `\n\nPS 2: <b>No spaces in the name due to unicodes</b>`,
        { parse_mode: 'HTML', reply_markup: keyboard }
    )
})

export default composer